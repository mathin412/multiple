# Youtube
Python: Real-time Single & Multiple Custom Object Detection with Colab (GPU), Yolov3 and OpenCV
1) Please access the folder - 1. Project - Custom Object Detection
2) Download Train_YoloV3_Multiple.ipynb for training custom objects
